// -*- Mode: Go; indent-tabs-mode: t -*-
//
// Copyright (C) 2018 IOTech Ltd
//
// SPDX-License-Identifier: Apache-2.0

package device_generic_mqtt

// Global version for device-sdk-go
var Version string = "to be replaced by makefile"
